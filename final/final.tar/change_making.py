
def change_making(d, n): 
    # your code goes here:
    pass



if __name__ == "__main__":
    d = [1,2,3]
    n = 10
    print(change_making(d,n))
