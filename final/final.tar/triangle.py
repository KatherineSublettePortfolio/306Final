
def triangle(board): 
    # your code goes here:
    pass



    


if __name__ == "__main__":
    board = [[2],[5,4],[1,4,7],[8,6,9,6]]
    print(triangle(board))


