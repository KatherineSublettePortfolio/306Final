
def matrix(board): 
    # your code goes here:
    pass





if __name__ == "__main__":
    board = [[1,2,3],[4,5,6],[7,0,2]]
    print(matrix(board))

